import tkinter as tk
import webbrowser, time
# from Pillow import Image
# from tkinter import ttk


def runYTVideo():
    url = url_entry.get()
    duration = time_entry.get()

    for i in range(15):
        webbrowser.open_new(url)
        time.sleep(int(duration))

root = tk.Tk()
root.title("YouTube Automator")
root.geometry("500x350")
root.config(bg='#222536')

# # Styles
# s = ttk.Style()
# s.configure('padStyle.TLabel', padding=(10,15,10,15))
# label = ttk.Label(root, text="My Label", style='padStyle.TLabel')


url_label = tk.Label(root, text="Enter YouTube Url: ", font=("Poppins", 14, 'bold'), fg="#fff", bg="#222536", pady=20)
url_label.pack()

url_entry = tk.Entry(root, font=("Poppins", 12), bg="#222536", fg="#ffffff", width=40)
url_entry.pack()

url_label = tk.Label(root, text="Enter time between replay: ", font=("Poppins", 14, 'bold'), fg="#fff", bg="#222536", pady=20)
url_label.pack()

time_entry = tk.Entry(root, font="Poppins", bg="#222536", fg="#ffffff", width=40)
time_entry.pack()

space_label = tk.Label(root, bg='#222536', pady=10)
space_label.pack()

run_button = tk.Button(root, text="Play Videos", font=("Poppins", 14, 'bold'), bg='red', fg='#222536', command=runYTVideo)
run_button.pack()

# Space
space_label = tk.Label(root, bg='#222536', pady=10)
space_label.pack()

dev_label = tk.Label(root, text="Developed by Elite Byte Code", font= ("Poppins", 12), fg='#fff', bg="#222536", pady=20)
dev_label.pack()

# image = Image.open("image.jpg")
# image = image.resize((200, 200), Image.ANTIALIAS)
# photo = ImageTk.PhotoImage(image)

# label = tk.Label(root, image=photo)
# label.pack()

root.mainloop()
